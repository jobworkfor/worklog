#-------------------------------------------------------------------------------
# Copyright (c) 2012 Manning
# See the file license.txt for copying permission.
#-------------------------------------------------------------------------------
#import <Foundation/Foundation.h>

@interface TextFormatter: NSObject

+ (NSString *)format:(NSString *)text;

@end
