/*******************************************************************************
 * Copyright (c) 2012 Manning
 * See the file license.txt for copying permission.
 ******************************************************************************/
package com.manning.androidhacks.hack017.view;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class CreateAccountContainer extends RelativeLayout {

  public CreateAccountContainer(Context context) {
    super(context);
  }

  public CreateAccountContainer(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  @Override
  public void setPressed(boolean pressed) {
    super.setPressed(pressed);
  }

}
